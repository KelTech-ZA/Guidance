# Guidance — Visual Coding Co-pilot
### Browser Extension · Chrome & Edge · Manifest V3

---

## What it does

Guidance watches ChatGPT, Claude, and Grok for code change instructions.
When it detects a change (a file name + code block), it:

1. **Badges the extension icon** with the number of pending changes.
2. **Shows a panel** in the popup with the exact file, the lines to delete (red),
   lines to insert (green), and lines to edit (amber).
3. **Colour-codes your project tabs** so you never edit the wrong file.

---

## Install on Windows (Chrome or Edge) — 3 steps

### Step 1 — Extract the extension folder
Unzip `guidance-extension.zip` somewhere permanent, e.g.
```
C:\Users\YourName\guidance-extension\
```
Do **not** delete or move this folder after installing — Chrome/Edge loads it live.

### Step 2 — Open Extensions page

**Chrome:**
1. Open Chrome → address bar → `chrome://extensions`
2. Toggle **Developer mode** ON (top-right switch)
3. Click **Load unpacked**
4. Select the `guidance-extension` folder → click **Select Folder**

**Edge:**
1. Open Edge → address bar → `edge://extensions`
2. Toggle **Developer mode** ON (bottom-left)
3. Click **Load unpacked**
4. Select the `guidance-extension` folder → click **Select Folder**

### Step 3 — Pin Guidance
- Click the puzzle piece (Extensions) icon in your toolbar
- Find **Guidance — Visual Coding Co-pilot** → click the pin icon
- The Guidance icon will now appear in your toolbar

---

## How to use

1. **Open ChatGPT, Claude, or Grok** and ask for a code change.
2. When the AI responds with a code block that includes a filename,
   Guidance auto-detects it. A small banner appears below the code block,
   and the extension badge shows a count.
3. **Click the Guidance icon** in your toolbar.
4. The **Patches** tab shows what file to edit, which lines to delete/add/change.
5. Go make the edit in your code editor (VS Code, Notepad++, etc.).
6. Come back and click **✓ Mark done** to clear the patch.

---

## Project colour coding

1. Click the Guidance icon → **Tab Colours** tab.
2. Type a project name (e.g. `src/aura/main`), pick a colour, click **+ Add**.
3. The tab preview shows how your files will look colour-coded.

> **Note:** The tab colour feature is a visual reference in the Guidance popup.
> Full in-editor tab highlighting requires the companion VS Code extension
> (coming in v1.1).

---

## Tier limits

| Feature | Free | Pro |
|---|---|---|
| Patch detection | ✓ | ✓ |
| Line highlights | ✓ | ✓ |
| Project colours | 5 | 10 |
| Shade variants | 1 | 3 |
| Auto AI detection | — | ✓ |

Switch tier: Guidance icon → **Settings** tab → click your plan.

---

## Supported AI sites

| Platform | URL |
|---|---|
| ChatGPT | chatgpt.com, chat.openai.com |
| Claude | claude.ai |
| Grok | grok.com, x.com |

---

## Troubleshooting

**Extension not detecting patches?**
- Make sure you're on chatgpt.com, claude.ai, or grok.com (not a mobile app).
- The AI response must contain a filename — either in the code header,
  in a comment at the top of the code block, or mentioned in the prose.
- Try reloading the AI page after installing the extension.

**"Could not load extension" error on install?**
- Make sure Developer mode is ON before clicking Load unpacked.
- Ensure the folder contains `manifest.json` at the root level.

---

## File structure

```
guidance-extension/
├── manifest.json        ← Extension config (Manifest V3)
├── background.js        ← Service worker: stores patches, manages badge
├── content-ai.js        ← Injected into AI pages: detects code patches
├── popup.html           ← Extension popup UI
├── popup.js             ← Popup logic: patches, colour coder, settings
├── gen_icons.py         ← Icon generator (already run — icons/ exists)
├── icons/
│   ├── icon16.png
│   ├── icon32.png
│   ├── icon48.png
│   └── icon128.png
└── README.md
```
