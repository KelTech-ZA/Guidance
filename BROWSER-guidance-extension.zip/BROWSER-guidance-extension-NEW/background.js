// Guidance — background.js (MV3 compatible)

const DEFAULT_SETTINGS = {
  tier: 'free',
  projects: [],
  pendingPatches: [],
  lastDetectedAt: null
};

const WS_PORT = 8765;

// ── Keep service worker alive ───────────────────────────────────────────
// MV3 service workers sleep after 30s — we use an alarm to keep alive
chrome.alarms.create('guidance-keepalive', { periodInMinutes: 0.4 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'guidance-keepalive') tryConnect();
});

// ── WebSocket state ─────────────────────────────────────────────────────
let ws = null;
let wsReady = false;

function tryConnect() {
  if (ws && (ws.readyState === 0 || ws.readyState === 1)) return; // already connecting/open
  try {
    ws = new WebSocket(`ws://127.0.0.1:${WS_PORT}`);
    ws.onopen = () => {
      wsReady = true;
      console.log('Guidance: connected to VS Code');
      // Flush any pending patches
      chrome.storage.local.get('settings', (data) => {
        const pending = (data.settings?.pendingPatches || []).filter(p => p.status === 'pending');
        pending.forEach(p => safeSend({ type: 'PATCH_DETECTED', ...p }));
      });
    };
    ws.onmessage = (e) => {
      try { handleVSCodeMessage(JSON.parse(e.data)); } catch(_) {}
    };
    ws.onclose = ws.onerror = () => {
      wsReady = false;
      ws = null;
    };
  } catch(_) {
    wsReady = false;
    ws = null;
  }
}

function safeSend(msg) {
  if (ws && ws.readyState === 1) {
    ws.send(JSON.stringify(msg));
    return true;
  }
  return false;
}

function handleVSCodeMessage(msg) {
  chrome.storage.local.get('settings', (data) => {
    const settings = data.settings || DEFAULT_SETTINGS;
    if (msg.type === 'PATCH_DONE') {
      settings.pendingPatches = settings.pendingPatches.map(p =>
        p.id === msg.id ? { ...p, status: 'done' } : p
      );
    }
    if (msg.type === 'PATCHES_CLEARED') {
      settings.pendingPatches = [];
    }
    const pending = settings.pendingPatches.filter(p => p.status === 'pending').length;
    chrome.storage.local.set({ settings }, () => {
      chrome.action.setBadgeText({ text: pending > 0 ? String(pending) : '' });
    });
  });
}

// ── Initialise ──────────────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get('settings', (data) => {
    if (!data.settings) chrome.storage.local.set({ settings: DEFAULT_SETTINGS });
  });
});

// Connect immediately on startup
tryConnect();
setTimeout(tryConnect, 3000);
setTimeout(tryConnect, 8000);

// ── Message router ──────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  if (msg.type === 'PATCH_DETECTED') {
    chrome.storage.local.get('settings', (data) => {
      const settings = data.settings || DEFAULT_SETTINGS;
      const patch = {
        id: Date.now(),
        detectedAt: new Date().toISOString(),
        source: msg.source,
        filename: msg.filename,
        language: msg.language,
        instructions: msg.instructions,
        deletions: msg.deletions || [],
        insertions: msg.insertions || [],
        edits: msg.edits || [],
        rawText: msg.rawText || '',
        status: 'pending'
      };
      settings.pendingPatches = [patch, ...settings.pendingPatches].slice(0, 20);
      settings.lastDetectedAt = patch.detectedAt;
      chrome.storage.local.set({ settings }, () => {
        const pending = settings.pendingPatches.filter(p => p.status === 'pending').length;
        chrome.action.setBadgeText({ text: String(pending) });
        chrome.action.setBadgeBackgroundColor({ color: '#EF9F27' });
        // Forward to VS Code
        if (!safeSend({ type: 'PATCH_DETECTED', ...patch })) {
          tryConnect(); // try to reconnect if not connected
        }
        sendResponse({ ok: true });
      });
    });
    return true;
  }

  if (msg.type === 'GET_SETTINGS') {
    chrome.storage.local.get('settings', (data) => {
      sendResponse(data.settings || DEFAULT_SETTINGS);
    });
    return true;
  }

  if (msg.type === 'SAVE_SETTINGS') {
    chrome.storage.local.set({ settings: msg.settings }, () => {
      const pending = (msg.settings.pendingPatches || []).filter(p => p.status === 'pending').length;
      chrome.action.setBadgeText({ text: pending > 0 ? String(pending) : '' });
      sendResponse({ ok: true });
    });
    return true;
  }

  if (msg.type === 'PATCH_DONE') {
    chrome.storage.local.get('settings', (data) => {
      const settings = data.settings || DEFAULT_SETTINGS;
      settings.pendingPatches = settings.pendingPatches.map(p =>
        p.id === msg.id ? { ...p, status: 'done' } : p
      );
      const pending = settings.pendingPatches.filter(p => p.status === 'pending').length;
      chrome.storage.local.set({ settings }, () => {
        chrome.action.setBadgeText({ text: pending > 0 ? String(pending) : '' });
        safeSend({ type: 'PATCH_DONE', id: msg.id });
        sendResponse({ ok: true });
      });
    });
    return true;
  }

  if (msg.type === 'CLEAR_PATCHES') {
    chrome.storage.local.get('settings', (data) => {
      const settings = data.settings || DEFAULT_SETTINGS;
      settings.pendingPatches = [];
      chrome.storage.local.set({ settings }, () => {
        chrome.action.setBadgeText({ text: '' });
        safeSend({ type: 'PATCHES_CLEARED' });
        sendResponse({ ok: true });
      });
    });
    return true;
  }

  if (msg.type === 'GET_WS_STATUS') {
    sendResponse({ connected: wsReady });
    return true;
  }
});
