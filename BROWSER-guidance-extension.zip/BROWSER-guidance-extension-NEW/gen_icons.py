#!/usr/bin/env python3
"""Generate PNG icons for the Guidance extension from an SVG template."""
import os, struct, zlib, base64

def make_png(size, bg='#534AB7'):
    """Create a simple PNG icon with the Guidance G logo."""
    # We'll write a minimal valid PNG using raw pixel data
    w = h = size
    
    # Parse hex color
    r = int(bg[1:3], 16)
    g = int(bg[3:5], 16)
    b = int(bg[5:7], 16)
    
    # Create pixel grid (RGBA)
    pixels = []
    cx, cy = w / 2, h / 2
    radius = w * 0.42
    ring = w * 0.12
    
    for y in range(h):
        row = []
        for x in range(w):
            dx, dy = x - cx, y - cy
            dist = (dx*dx + dy*dy) ** 0.5
            
            # Rounded square background
            bx = abs(x - cx) / (w * 0.47)
            by = abs(y - cy) / (h * 0.47)
            in_bg = (bx**8 + by**8) < 1.0
            
            # Circle outline
            in_circle = abs(dist - radius) < ring * 0.55
            
            # Plus sign
            arm_w = w * 0.08
            in_h = abs(dy) < arm_w and abs(dx) < radius * 0.55
            in_v = abs(dx) < arm_w and abs(dy) < radius * 0.55
            in_plus = in_h or in_v
            
            if in_bg:
                if in_circle or in_plus:
                    row += [255, 255, 255, 255]  # white
                else:
                    row += [r, g, b, 255]  # brand color
            else:
                row += [0, 0, 0, 0]  # transparent
        pixels.append(bytes(row))
    
    # Build PNG
    def chunk(name, data):
        c = name + data
        return struct.pack('>I', len(data)) + c + struct.pack('>I', zlib.crc32(c) & 0xffffffff)
    
    raw = b''
    for row in pixels:
        raw += b'\x00' + row  # filter type none
    
    compressed = zlib.compress(raw, 9)
    
    png = b'\x89PNG\r\n\x1a\n'
    png += chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 6, 0, 0, 0))
    png += chunk(b'IDAT', compressed)
    png += chunk(b'IEND', b'')
    
    return png

os.makedirs('icons', exist_ok=True)
for size in [16, 32, 48, 128]:
    png_data = make_png(size)
    with open(f'icons/icon{size}.png', 'wb') as f:
        f.write(png_data)
    print(f'Created icons/icon{size}.png ({size}x{size})')

print('Icons generated successfully.')
