// Guidance — popup.js

const MAIN_COLORS = [
  { hex: '#534AB7', mid: '#AFA9EC', light: '#EEEDFE', textDark: '#3C3489', label: 'Purple' },
  { hex: '#1D9E75', mid: '#5DCAA5', light: '#E1F5EE', textDark: '#085041', label: 'Teal' },
  { hex: '#D85A30', mid: '#F0997B', light: '#FAECE7', textDark: '#712B13', label: 'Coral' },
  { hex: '#185FA5', mid: '#85B7EB', light: '#E6F1FB', textDark: '#0C447C', label: 'Blue' },
  { hex: '#639922', mid: '#97C459', light: '#EAF3DE', textDark: '#27500A', label: 'Green' },
  { hex: '#D4537E', mid: '#ED93B1', light: '#FBEAF0', textDark: '#72243E', label: 'Pink' },
  { hex: '#BA7517', mid: '#EF9F27', light: '#FAEEDA', textDark: '#633806', label: 'Amber' },
  { hex: '#888780', mid: '#B4B2A9', light: '#F1EFE8', textDark: '#444441', label: 'Gray' },
  { hex: '#E24B4A', mid: '#F09595', light: '#FCEBEB', textDark: '#791F1F', label: 'Red' },
  { hex: '#4B3A8C', mid: '#7F77DD', light: '#CECBF6', textDark: '#26215C', label: 'Indigo' }
];

let settings = null;
let selMainIdx = 0;
let selShadeIdx = 0;

const BACKEND_URL = 'https://guidance-backend-396822769279.us-central1.run.app';

// ── Boot ────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {

  // Nav tabs
  document.getElementById('nb0').addEventListener('click', () => goTab(0));
  document.getElementById('nb1').addEventListener('click', () => goTab(1));
  document.getElementById('nb2').addEventListener('click', () => goTab(2));

  // Clear all patches
  document.getElementById('clearBtn').addEventListener('click', clearAll);

  // Add project
  document.getElementById('addProjBtn').addEventListener('click', addProject);
  document.getElementById('projNameInput').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') addProject();
  });

  // Upgrade links
  document.getElementById('mainLckLink').addEventListener('click', () => goTab(2));
  document.getElementById('shadeLckLink').addEventListener('click', () => goTab(2));

  // Tier cards
  document.getElementById('tcFree').addEventListener('click', () => setTier('free'));
  document.getElementById('tcPro').addEventListener('click', () => setTier('pro'));

  // Licence activation
  document.getElementById('activateBtn').addEventListener('click', activateLicence);
  document.getElementById('licenceInput').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') activateLicence();
  });
  document.getElementById('deactivateBtn').addEventListener('click', deactivateLicence);

  // Upgrade button — open payment page
  document.getElementById('upgradeBtn').addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://www.capitlrsa.com/guidance#upgrade' });
  });

  // Load settings then render
  chrome.runtime.sendMessage({ type: 'GET_SETTINGS' }, (s) => {
    settings = s;
    renderAll();
    renderLicenceUI();
  });
});

function renderAll() {
  renderStatus();
  renderPatches();
  renderColourCoder();
  renderTierCards();
}

// ── Tab navigation ──────────────────────────────────────────────────────
function goTab(i) {
  document.querySelectorAll('.screen').forEach((s, j) => s.classList.toggle('active', j === i));
  document.querySelectorAll('.nb').forEach((b, j) => b.classList.toggle('on', j === i));
  if (i === 1) renderColourCoder();
}

// ── Patch list event delegation ─────────────────────────────────────────
document.addEventListener('click', (e) => {
  const btn = e.target.closest('[data-action]');
  if (!btn) return;
  const id = parseInt(btn.dataset.id);
  if (btn.dataset.action === 'done') markDone(id);
  if (btn.dataset.action === 'copy') copyPatch(id);
  if (btn.dataset.action === 'pickMain') pickMain(parseInt(btn.dataset.idx));
  if (btn.dataset.action === 'pickShade') pickShade(parseInt(btn.dataset.idx));
  if (btn.dataset.action === 'removeProj') removeProject(parseInt(btn.dataset.idx));
});

// ── Status bar ──────────────────────────────────────────────────────────
function renderStatus() {
  const pending = (settings.pendingPatches || []).filter(p => p.status === 'pending');
  const dot = document.getElementById('statusDot');
  const txt = document.getElementById('statusText');
  if (pending.length > 0) {
    dot.style.background = '#EF9F27';
    txt.textContent = `${pending.length} change${pending.length > 1 ? 's' : ''} waiting for your edit`;
  } else {
    dot.style.background = '#1D9E75';
    txt.textContent = 'Watching for AI code instructions…';
  }
}

// ── Patch list ──────────────────────────────────────────────────────────
function renderPatches() {
  const list = document.getElementById('patchList');
  const patches = settings.pendingPatches || [];
  if (patches.length === 0) {
    list.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">👁️</div>
        <div class="empty-title">No patches detected yet</div>
        <div class="empty-sub">Open ChatGPT, Claude or Grok and ask for a code change.<br>Guidance will pick it up automatically.</div>
      </div>`;
    return;
  }

  list.innerHTML = patches.map(p => {
    const srcClass = `src-${p.source}`;
    const srcLabel = { chatgpt: 'ChatGPT', claude: 'Claude', grok: 'Grok' }[p.source] || p.source;
    const timeStr = p.detectedAt ? new Date(p.detectedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '';
    const isDone = p.status === 'done';

    const diffLines = buildDiffLines(p);

    return `
      <div class="patch-card" id="patch-${p.id}">
        <div class="patch-head ${isDone ? 'done-head' : ''}">
          <span class="file-badge">${escHtml(p.filename || 'unknown file')}</span>
          <span class="source-tag ${srcClass}">${srcLabel}</span>
          <span class="patch-time">${timeStr}</span>
        </div>
        <div class="patch-body">
          ${p.instructions ? `<div class="patch-instr">${escHtml(p.instructions.slice(0, 180))}${p.instructions.length > 180 ? '…' : ''}</div>` : ''}
          ${diffLines.length > 0 ? `
            <div class="diff-block">
              ${diffLines.map(l => `
                <div class="diff-line ${l.cls}">
                  <span class="diff-symbol">${l.sym}</span>
                  <span>${escHtml(l.code)}</span>
                </div>`).join('')}
            </div>` : `
            <div style="font-family:monospace;font-size:11px;background:#f7f6f3;border-radius:6px;padding:8px;max-height:120px;overflow-y:auto;white-space:pre-wrap;color:#555;margin-bottom:8px">${escHtml((p.rawText || '').slice(0, 400))}${(p.rawText || '').length > 400 ? '\n…' : ''}</div>
          `}
          ${isDone
            ? `<div class="done-stamp">✓ Marked as done</div>`
            : `<div class="patch-actions">
                <button class="btn sm" data-action="done" data-id="${p.id}" style="background:#534AB7;color:#fff;border:none">✓ Mark done</button>
                <button class="btn sm sec" data-action="copy" data-id="${p.id}">Copy code</button>
               </div>`
          }
        </div>
      </div>`;
  }).join('');
}

function buildDiffLines(patch) {
  const lines = [];
  (patch.deletions || []).forEach(d => lines.push({ cls: 'diff-del', sym: '−', code: d.code }));
  (patch.insertions || []).forEach(i => lines.push({ cls: 'diff-ins', sym: '+', code: i.code }));
  (patch.edits || []).forEach(e => lines.push({ cls: 'diff-edit', sym: '~', code: e.code || e }));
  return lines.slice(0, 12);
}

function markDone(id) {
  settings.pendingPatches = settings.pendingPatches.map(p =>
    p.id === id ? { ...p, status: 'done' } : p
  );
  saveSettings();
  renderPatches();
  renderStatus();
}

function copyPatch(id) {
  const p = (settings.pendingPatches || []).find(x => x.id === id);
  if (p && p.rawText) {
    navigator.clipboard.writeText(p.rawText).catch(() => {});
  }
}

function clearAll() {
  settings.pendingPatches = [];
  saveSettings();
  renderPatches();
  renderStatus();
}

// ── Colour coder ────────────────────────────────────────────────────────
function renderColourCoder() {
  const isPro = settings.tier === 'pro';
  const maxColors = isPro ? 10 : 5;
  const maxShades = isPro ? 3 : 1;

  // Main swatches
  const msw = document.getElementById('mainSw');
  msw.innerHTML = MAIN_COLORS.map((c, i) => {
    const locked = i >= maxColors;
    return `<div class="sw${selMainIdx === i ? ' on' : ''}${locked ? ' locked' : ''}"
      style="background:${c.hex}"
      title="${c.label}${locked ? ' (Pro only)' : ''}"
      data-action="pickMain" data-idx="${i}"></div>`;
  }).join('');

  document.getElementById('mainLck').style.display = isPro ? 'none' : 'flex';

  // Shade row
  const c = MAIN_COLORS[selMainIdx];
  const shades = [c.hex, c.mid, c.light];
  const shRow = document.getElementById('shadeRow');
  shRow.innerHTML = shades.map((hex, i) => {
    const locked = i >= maxShades;
    return `<div class="sh${selShadeIdx === i ? ' on' : ''}${locked ? ' locked' : ''}"
      style="background:${hex};${i === 2 ? 'border:1.5px dashed #ccc;' : ''}"
      title="${locked ? 'Pro only' : 'Shade ' + (i + 1)}"
      data-action="pickShade" data-idx="${i}"></div>`;
  }).join('');

  document.getElementById('shadeLck').style.display = isPro ? 'none' : 'flex';

  // Project count label
  const maxProj = isPro ? 10 : 5;
  document.getElementById('projCountLabel').textContent = `(${(settings.projects || []).length}/${maxProj})`;

  renderProjList();
  renderTabPreview();
}

function pickMain(i) {
  const isPro = settings.tier === 'pro';
  const maxColors = isPro ? 10 : 5;
  if (i >= maxColors) {
    document.getElementById('mainLck').style.display = 'flex';
    return;
  }
  selMainIdx = i;
  selShadeIdx = 0;
  renderColourCoder();
}

function pickShade(i) {
  const isPro = settings.tier === 'pro';
  const maxShades = isPro ? 3 : 1;
  if (i >= maxShades) return;
  selShadeIdx = i;
  renderColourCoder();
}

// ── Project list ────────────────────────────────────────────────────────
function renderProjList() {
  const list = document.getElementById('projList');
  const projects = settings.projects || [];
  if (projects.length === 0) {
    list.innerHTML = `<div style="font-size:11px;color:#bbb;text-align:center;padding:8px">No projects yet — add one above</div>`;
    return;
  }
  list.innerHTML = projects.map((p, idx) => `
    <div class="proj-row">
      <div class="proj-dot" style="background:${p.color}"></div>
      <div class="proj-name">${escHtml(p.name)}</div>
      <button class="proj-del" data-action="removeProj" data-idx="${idx}" title="Remove">✕</button>
    </div>`).join('');
}

function addProject() {
  const input = document.getElementById('projNameInput');
  const name = input.value.trim();
  if (!name) return;
  const isPro = settings.tier === 'pro';
  const maxProj = isPro ? 10 : 5;
  if ((settings.projects || []).length >= maxProj) {
    alert(`You've reached the ${isPro ? 'Pro' : 'Free'} limit of ${maxProj} projects.`);
    return;
  }
  const c = MAIN_COLORS[selMainIdx];
  const shades = [c.hex, c.mid, c.light];
  const color = shades[selShadeIdx] || c.hex;
  settings.projects = [...(settings.projects || []), { name, color, mainIdx: selMainIdx, shadeIdx: selShadeIdx }];
  input.value = '';
  saveSettings();
  renderColourCoder();
}

function removeProject(idx) {
  settings.projects.splice(idx, 1);
  saveSettings();
  renderColourCoder();
}

// ── Tab preview ─────────────────────────────────────────────────────────
function renderTabPreview() {
  const prev = document.getElementById('tabPreview');
  const projects = settings.projects || [];

  const demos = projects.length > 0 ? projects : [
    { name: 'src/aura/main.js', color: '#534AB7', mainIdx: 0 },
    { name: 'src/nexus/index.py', color: '#1D9E75', mainIdx: 1 },
    { name: 'src/forge/app.ts', color: '#D85A30', mainIdx: 2 }
  ];

  prev.innerHTML = demos.slice(0, 8).map(p => {
    const mc = MAIN_COLORS[p.mainIdx] || MAIN_COLORS[0];
    return `<div class="ptab" style="background:${mc.light};color:${mc.textDark};border-color:${mc.mid}">
      <span class="pdot" style="background:${p.color}"></span>${escHtml(p.name)}
    </div>`;
  }).join('');
}

// ── Tier cards ──────────────────────────────────────────────────────────
function renderTierCards() {
  const tier = settings.tier || 'free';
  document.getElementById('tcFree').classList.toggle('sel', tier === 'free');
  document.getElementById('tcPro').classList.toggle('sel', tier === 'pro');
}

function setTier(t) {
  settings.tier = t;
  saveSettings();
  renderTierCards();
  renderColourCoder();
}

// ── Licence activation ──────────────────────────────────────────────────
function renderLicenceUI() {
  const isPro = settings.tier === 'pro' && settings.licenceKey;
  document.getElementById('freeBox').style.display = isPro ? 'none' : 'block';
  document.getElementById('proBox').style.display = isPro ? 'block' : 'none';
  if (isPro && settings.licenceEmail) {
    document.getElementById('proEmail').textContent = settings.licenceEmail;
  }
  // Update tier cards
  document.getElementById('tcFree').classList.toggle('sel', !isPro);
  document.getElementById('tcPro').classList.toggle('sel', isPro);
}

async function activateLicence() {
  const key = document.getElementById('licenceInput').value.trim().toUpperCase();
  const msg = document.getElementById('licenceMsg');
  const btn = document.getElementById('activateBtn');

  if (!key || key.length < 10) {
    msg.textContent = 'Please enter a valid licence key.';
    msg.style.display = 'block';
    msg.style.color = '#A32D2D';
    return;
  }

  btn.textContent = 'Checking…';
  btn.disabled = true;
  msg.style.display = 'none';

  try {
    const res = await fetch(`${BACKEND_URL}/licence/validate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ licence_key: key })
    });
    const data = await res.json();

    if (data.valid && data.tier === 'pro') {
      settings.tier = 'pro';
      settings.licenceKey = key;
      settings.licenceEmail = data.email || '';
      saveSettings();
      renderAll();
      renderLicenceUI();
      msg.textContent = '✓ ' + data.message;
      msg.style.color = '#085041';
      msg.style.display = 'block';
    } else {
      msg.textContent = data.message || 'Invalid licence key.';
      msg.style.color = '#A32D2D';
      msg.style.display = 'block';
    }
  } catch(e) {
    msg.textContent = 'Could not connect to server. Check your internet connection.';
    msg.style.color = '#A32D2D';
    msg.style.display = 'block';
  }

  btn.textContent = 'Activate';
  btn.disabled = false;
}

function deactivateLicence() {
  settings.tier = 'free';
  settings.licenceKey = null;
  settings.licenceEmail = null;
  saveSettings();
  renderAll();
  renderLicenceUI();
}

// ── Persist ─────────────────────────────────────────────────────────────
function saveSettings() {
  chrome.runtime.sendMessage({ type: 'SAVE_SETTINGS', settings }, () => {});
}

// ── Utils ────────────────────────────────────────────────────────────────
function escHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
