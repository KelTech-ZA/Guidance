// Guidance content-ai.js v5
// Platform-specific + universal selectors for ChatGPT, Claude, and Grok

(function () {
  'use strict';
  if (window.__guidanceV5) return;
  window.__guidanceV5 = true;

  const HOST = location.hostname;
  const SOURCE_MAP = {
    'chatgpt.com': 'chatgpt', 'chat.openai.com': 'chatgpt',
    'claude.ai': 'claude',
    'grok.com': 'grok', 'x.com': 'grok',
    'gemini.google.com': 'gemini', 'bard.google.com': 'gemini'
  };
  const source = SOURCE_MAP[HOST] || 'unknown';

  const FILE_RE = /([A-Za-z]:[\\\/][\w\\\/\-. ]+\.[\w]+|[\w\-./\\]+\.(js|ts|py|html|css|json|jsx|tsx|php|rb|java|cs|go|rs|cpp|c|sh|yaml|yml|xml|env|md|vue|scss|sass|less|swift|kt|dart))/i;

  const sentKeys = new Set();

  // ── Platform-specific selectors ──────────────────────────────────────
  const PLATFORM_SELECTORS = {
    chatgpt: [
      // ChatGPT uses div-based code rendering, not pre>code
      '[data-message-author-role="assistant"] pre',
      '[data-message-author-role="assistant"] code',
      'div[class*="overflow-y-auto"] pre',
      'div[class*="markdown"] pre',
      'div[class*="prose"] pre',
      // ChatGPT streaming renders into these
      'div[class*="text-sm"] pre',
      'div[class*="rounded-md"] pre',
      // Fallback — any pre in the conversation
      'div[id*="message"] pre',
      'article pre',
    ],
    claude: [
      // Claude uses standard pre>code inside their message component
      '.font-claude-message pre code',
      '.font-claude-message pre',
      '[data-testid="assistant-message"] pre code',
      '[data-testid="assistant-message"] pre',
      // Claude artifact viewer
      '[class*="artifact"] pre code',
      '[class*="artifact"] pre',
      // Generic claude message containers
      '[class*="prose"] pre code',
      '[class*="prose"] pre',
      // Fallback
      'div[class*="message"] pre code',
    ],
    grok: [
      // Grok / X.com message containers
      '[class*="message-bubble"] pre code',
      '[class*="message-bubble"] pre',
      '[class*="MessageBubble"] pre code',
      '[class*="MessageBubble"] pre',
      '[class*="response"] pre code',
      '[class*="response"] pre',
      '[class*="assistant"] pre code',
      '[class*="assistant"] pre',
      // X.com Grok embed
      '[data-testid*="grok"] pre',
      'div[class*="r-"] pre', // Grok uses Tailwind-like r- classes
      // Fallback
      'article pre code',
      'article pre',
    ],
    gemini: [
      // Gemini uses Angular-based components with mat- and model-response tags
      'model-response pre code',
      'model-response pre',
      'message-content pre code',
      'message-content pre',
      '.response-content pre code',
      '.response-content pre',
      // Gemini markdown renderer
      '[class*="markdown"] pre code',
      '[class*="markdown"] pre',
      'div[class*="code-block"] pre code',
      'div[class*="code-block"] pre',
      // Gemini uses mat-* Angular Material components
      'mat-card pre code',
      'mat-card pre',
      // Gemini response container
      '[data-response-index] pre code',
      '[data-response-index] pre',
      // Fallback
      'article pre code',
      'article pre',
    ]
  };

  // Universal fallback selectors tried for ALL platforms
  const UNIVERSAL_SELECTORS = [
    'pre code', 'pre',
    'code[class*="language"]',
    '[class*="code-block"] code',
    '[class*="codeBlock"] code',
    '[class*="highlight"] code',
    '[class*="syntax"] code',
    '.hljs',
  ];

  function findAllCodeBlocks() {
    const results = new Set();
    const platformSels = PLATFORM_SELECTORS[source] || [];
    const allSels = [...platformSels, ...UNIVERSAL_SELECTORS];

    allSels.forEach(sel => {
      try {
        document.querySelectorAll(sel).forEach(el => {
          const text = (el.textContent || '').trim();
          if (text.length > 30) results.add(el);
        });
      } catch(e) {}
    });

    return Array.from(results);
  }

  // ── Find message container ───────────────────────────────────────────
  function findMsg(el) {
    const byPlatform = {
      chatgpt: ['[data-message-author-role="assistant"]', 'article', '[class*="group"]'],
      claude: ['.font-claude-message', '[data-testid="assistant-message"]', '[class*="message"]'],
      grok: ['[class*="message-bubble"]', '[class*="MessageBubble"]', '[class*="response"]', 'article'],
      gemini: ['model-response', 'message-content', '[class*="response-content"]', '[data-response-index]', 'article']
    };
    const selectors = [
      ...(byPlatform[source] || []),
      '[data-message-author-role="assistant"]',
      '[data-testid*="message"]',
      'article', '[class*="message"]'
    ];
    for (const sel of selectors) {
      try {
        const found = el.closest(sel);
        if (found) return found;
      } catch(e) {}
    }
    return null;
  }

  // ── Extract filename ─────────────────────────────────────────────────
  function extractFilename(el) {
    const text = el.textContent || '';

    // 1. First 6 lines — strip comment markers
    const lines = text.split('\n').slice(0, 6);
    for (const line of lines) {
      const clean = line
        .replace(/^[\s]*(?:<!--|\/\/|\/\*|#|\*)[\s]*/g, '')
        .replace(/[\s]*(?:-->|\*\/)[\s]*$/g, '').trim();
      const m = clean.match(FILE_RE);
      if (m) return m[0].trim();
    }

    // 2. Element directly before this block
    let sib = el.previousElementSibling;
    if (!sib && el.parentElement) sib = el.parentElement.previousElementSibling;
    if (sib) {
      const t = sib.textContent || '';
      const m = t.match(FILE_RE);
      if (m) return m[0].trim();
      for (const c of sib.querySelectorAll('code, strong, span')) {
        const ct = (c.textContent || '').trim();
        if (ct.length < 80 && FILE_RE.test(ct)) return ct.match(FILE_RE)[0].trim();
      }
    }

    // 3. Walk up DOM looking for header/label with filename
    let parent = el.parentElement;
    for (let i = 0; i < 6 && parent; i++, parent = parent.parentElement) {
      const prev = parent.previousElementSibling;
      if (prev) {
        const t = (prev.textContent || '').slice(0, 200);
        const m = t.match(FILE_RE);
        if (m) return m[0].trim();
      }
      for (const child of parent.querySelectorAll('span, div, button, label, p')) {
        if (child.contains(el)) continue;
        if (child.children.length > 3) continue;
        const t = (child.textContent || '').trim();
        if (t.length > 0 && t.length < 100 && FILE_RE.test(t)) {
          return t.match(FILE_RE)[0].trim();
        }
      }
    }

    // 4. Message container prose
    const msg = findMsg(el);
    if (msg) {
      for (const c of msg.querySelectorAll('code')) {
        if (c === el || c.contains(el) || el.contains(c)) continue;
        const t = (c.textContent || '').trim();
        if (t.length < 80 && FILE_RE.test(t)) return t.match(FILE_RE)[0].trim();
      }
      const prose = (msg.innerText || '').slice(0, 1000);
      const pats = [
        /(?:in|edit|open|update|modify|to|file|for)\s+[`"']?([A-Za-z]:[\\\/][\w\\\/\-. ]+\.[\w]+)[`"']?/i,
        /(?:in|edit|open|update|modify|to|file|for)\s+[`"']?([\w\-./\\]+\.(js|ts|py|html|css|json|jsx|tsx|php|rb|java|cs))[`"']?/i,
        /[`]([\w\-./\\]+\.(js|ts|py|html|css|json|jsx|tsx|php|rb|java|cs))[`]/i,
        /([\w\-./\\]+\.(js|ts|py|html|css|json|jsx|tsx|php|rb|java|cs))[\s:,\n(]/i,
      ];
      for (const p of pats) { const m = prose.match(p); if (m) return (m[1] || m[0]).trim(); }
    }

    return null;
  }

  // ── Stable dedup key ─────────────────────────────────────────────────
  function getKey(el) {
    const text = (el.textContent || '').trim();
    const msg = findMsg(el);
    const msgs = document.querySelectorAll(
      '[data-message-author-role="assistant"], .font-claude-message, [class*="message-bubble"], article'
    );
    const msgIdx = msg ? Array.from(msgs).indexOf(msg) : 0;
    return `${msgIdx}::${text.slice(0, 80)}`;
  }

  // ── Diff analysis ────────────────────────────────────────────────────
  function analyseDiff(text) {
    const dels = [], ins = [];
    text.split('\n').forEach((line, i) => {
      if (/^---/.test(line) || /^\+\+\+/.test(line)) return;
      if (/^-[^-\s]/.test(line) || /^- /.test(line)) dels.push({ lineHint: i + 1, code: line.slice(1).trim() });
      else if (/^\+[^+\s]/.test(line) || /^\+ /.test(line)) ins.push({ lineHint: i + 1, code: line.slice(1).trim() });
    });
    return { deletions: dels, insertions: ins, edits: [] };
  }

  // ── Send patch + show banner ─────────────────────────────────────────
  function sendPatch(el, filename) {
    const code = (el.textContent || '').trim();
    const { deletions, insertions, edits } = analyseDiff(code);
    const msg = findMsg(el);
    const instructions = msg ? (msg.innerText || '').replace(code, '').trim().slice(0, 400) : '';

    chrome.runtime.sendMessage({
      type: 'PATCH_DETECTED', source, filename,
      language: detectLang(el), instructions,
      deletions, insertions, edits,
      rawText: code.slice(0, 3000)
    }, () => { if (chrome.runtime.lastError) {} });

    // Purple banner below code block
    try {
      const container = el.closest('pre') || el.parentElement || el;
      if (!container.querySelector('.g-banner')) {
        const b = document.createElement('div');
        b.className = 'g-banner';
        b.style.cssText = 'font-size:11px;padding:4px 12px;background:#EEEDFE;color:#534AB7;border-top:2px solid #534AB7;font-family:sans-serif;display:flex;align-items:center;gap:6px';
        b.innerHTML = `<strong>Guidance ✓</strong>&nbsp;<code style="background:#dcd9f5;padding:1px 5px;border-radius:3px">${filename}</code>&nbsp;→ sent to VS Code`;
        container.appendChild(b);
      }
    } catch(e) {}
  }

  function detectLang(el) {
    const cls = (el.className || '') + ' ' + ((el.closest('pre') || {}).className || '');
    const m = cls.match(/language-(\w+)/);
    if (m) return m[1];
    return 'code';
  }

  // ── Main scan ────────────────────────────────────────────────────────
  function scan() {
    const blocks = findAllCodeBlocks();
    let sent = 0;
    blocks.forEach(el => {
      const key = getKey(el);
      if (sentKeys.has(key)) return;
      const filename = extractFilename(el);
      if (!filename) return;
      sentKeys.add(key);
      sent++;
      sendPatch(el, filename);
    });
    return { total: blocks.length, sent };
  }

  // ── Debug helpers ────────────────────────────────────────────────────
  window.__guidanceScan = () => {
    sentKeys.clear();
    const r = scan();
    console.log(`Guidance v6 [${source}]: scanned ${r.total} blocks, sent ${r.sent} patches`);
    return r;
  };
  window.__guidanceInspect = () => {
    const blocks = findAllCodeBlocks();
    console.log(`Guidance v5 [${source}]: ${blocks.length} code blocks found`);
    blocks.slice(0, 8).forEach((b, i) => {
      const fn = extractFilename(b);
      console.log(`  [${i}] <${b.tagName}> class="${b.className.slice(0,40)}" filename="${fn}" text="${b.textContent.trim().slice(0,50)}"`);
    });
  };

  // ── Watch for new content ────────────────────────────────────────────
  let t = null;
  new MutationObserver(() => { clearTimeout(t); t = setTimeout(scan, 800); })
    .observe(document.body, { childList: true, subtree: true });

  setTimeout(scan, 1500);
  setTimeout(scan, 4000);
  setTimeout(scan, 8000);

  console.log(`Guidance v6: loaded on ${HOST} (source: ${source})`);
})();
