@echo off
echo.
echo  ========================================
echo   Guidance VS Code Extension Installer
echo  ========================================
echo.

REM Check if VS Code is installed
where code >nul 2>&1
if %errorlevel% neq 0 (
    echo  [!] VS Code not found in PATH.
    echo      Please make sure VS Code is installed and try again.
    echo      Download from: https://code.visualstudio.com
    pause
    exit /b 1
)

REM Check if Node.js / npm is available
where npm >nul 2>&1
if %errorlevel% neq 0 (
    echo  [!] npm not found. Installing Node.js is required.
    echo      Download from: https://nodejs.org  (LTS version)
    echo      After installing Node.js, run this installer again.
    pause
    exit /b 1
)

echo  [1/3] Installing dependencies...
cd /d "%~dp0guidance-vscode"
npm install ws --save
if %errorlevel% neq 0 (
    echo  [!] npm install failed. Check your internet connection.
    pause
    exit /b 1
)

echo  [2/3] Copying extension to VS Code extensions folder...
set EXTDIR=%USERPROFILE%\.vscode\extensions\guidance-vscode
if exist "%EXTDIR%" rmdir /s /q "%EXTDIR%"
xcopy /e /i /q "%~dp0guidance-vscode" "%EXTDIR%"
if %errorlevel% neq 0 (
    echo  [!] Copy failed. Try running as Administrator.
    pause
    exit /b 1
)

echo  [3/3] Done!
echo.
echo  ========================================
echo   Guidance VS Code extension installed!
echo  ========================================
echo.
echo  Next steps:
echo   1. Open VS Code (or restart it if already open)
echo   2. You will see "Guidance: ready" in the status bar
echo   3. Open your project folder in VS Code
echo   4. Ask ChatGPT / Claude / Grok for a code change
echo   5. Watch Guidance highlight the exact lines in VS Code
echo.
echo  Also make sure the Guidance browser extension is installed
echo  and enabled in Edge/Chrome (already done if you're reading this!)
echo.
pause
