# Guidance VS Code Extension

Works together with the Guidance browser extension to highlight
exactly where to make AI-suggested code changes — directly inside VS Code.

## How it works

```
ChatGPT / Claude / Grok
        ↓
Guidance browser extension (detects the patch)
        ↓  WebSocket on localhost:8765
Guidance VS Code extension (lights up your file)
        ↓
Red lines  = delete these
Green lines = insert here  
Amber lines = edit these
        ↓
Press Ctrl+S → highlights clear automatically
```

## Install

### Step 1 — Install Node.js (if not already installed)
Download from https://nodejs.org (LTS version)

### Step 2 — Run the installer
Double-click `install.bat` in this folder.
It will:
- Run `npm install` to get the WebSocket library
- Copy the extension into your VS Code extensions folder

### Step 3 — Restart VS Code
You should see **"Guidance: ready"** in the bottom status bar.

### Step 4 — Open your project
Open your project folder in VS Code (File → Open Folder).

---

## Usage

1. Go to ChatGPT, Claude, or Grok in your browser
2. Ask for a code change (e.g. "fix the console.log in app.js")
3. When the AI responds, Guidance detects the patch automatically
4. Switch to VS Code — the correct file opens, lines are highlighted
5. Make the edit
6. Press **Ctrl+S** — highlights clear, patch marked done

## Commands (Ctrl+Shift+P)

| Command | What it does |
|---|---|
| `Guidance: Show Pending Patches` | Opens the patch panel |
| `Guidance: Clear All Patches` | Removes all highlights |
| `Guidance: Mark Current File Done` | Marks current file's patch as done |

## Settings

Go to File → Preferences → Settings → search "Guidance":

| Setting | Default | Description |
|---|---|---|
| `guidance.port` | 8765 | WebSocket port |
| `guidance.autoReveal` | true | Auto-scroll to highlighted lines |

## Troubleshooting

**Status bar shows "Guidance: waiting…" not "ready"**
The browser extension hasn't connected yet. Make sure:
- The browser extension is installed and enabled
- You've visited a ChatGPT/Claude/Grok page at least once

**"Could not find file" warning**
Make sure you've opened your project folder in VS Code
(File → Open Folder → select your project root).
Guidance searches your workspace for the filename.

**install.bat fails**
- Make sure Node.js is installed first
- Try right-clicking install.bat → "Run as Administrator"
