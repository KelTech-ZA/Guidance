// Guidance VS Code Extension v3
// Includes: patch detection, line highlights, tab colour coding via workspace settings

const vscode = require('vscode');
const path = require('path');
const fs = require('fs');

let wsServer = null;
let statusBarItem = null;
let patches = [];
let decorDelete, decorInsert, decorEdit;

// ── Colour palette (10 main + 3 shades each) ────────────────────────────
const COLOURS = [
  { name: 'Purple',  shades: ['#534AB7', '#AFA9EC', '#EEEDFE'] },
  { name: 'Teal',    shades: ['#1D9E75', '#5DCAA5', '#E1F5EE'] },
  { name: 'Coral',   shades: ['#D85A30', '#F0997B', '#FAECE7'] },
  { name: 'Blue',    shades: ['#185FA5', '#85B7EB', '#E6F1FB'] },
  { name: 'Green',   shades: ['#639922', '#97C459', '#EAF3DE'] },
  { name: 'Pink',    shades: ['#D4537E', '#ED93B1', '#FBEAF0'] },
  { name: 'Amber',   shades: ['#BA7517', '#EF9F27', '#FAEEDA'] },
  { name: 'Gray',    shades: ['#888780', '#B4B2A9', '#F1EFE8'] },
  { name: 'Red',     shades: ['#E24B4A', '#F09595', '#FCEBEB'] },
  { name: 'Indigo',  shades: ['#4B3A8C', '#7F77DD', '#CECBF6'] }
];

// ── Create line decorations ─────────────────────────────────────────────
function createDecorations() {
  decorDelete = vscode.window.createTextEditorDecorationType({
    backgroundColor: 'rgba(162,45,45,0.2)',
    isWholeLine: true,
    overviewRulerColor: '#A32D2D',
    overviewRulerLane: vscode.OverviewRulerLane.Right,
    after: { contentText: '  ← DELETE', color: '#A32D2D', fontStyle: 'italic', fontSize: '11px' }
  });
  decorInsert = vscode.window.createTextEditorDecorationType({
    backgroundColor: 'rgba(29,158,117,0.18)',
    isWholeLine: true,
    overviewRulerColor: '#1D9E75',
    overviewRulerLane: vscode.OverviewRulerLane.Right,
    after: { contentText: '  ← INSERT', color: '#0F6E56', fontStyle: 'italic', fontSize: '11px' }
  });
  decorEdit = vscode.window.createTextEditorDecorationType({
    backgroundColor: 'rgba(239,159,39,0.2)',
    isWholeLine: true,
    overviewRulerColor: '#EF9F27',
    overviewRulerLane: vscode.OverviewRulerLane.Right,
    after: { contentText: '  ← EDIT', color: '#BA7517', fontStyle: 'italic', fontSize: '11px' }
  });
}

// ── Activate ────────────────────────────────────────────────────────────
function activate(context) {
  createDecorations();

  // Status bar
  statusBarItem = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 100);
  statusBarItem.command = 'guidance.showPatches';
  statusBarItem.text = '$(eye) Guidance: starting…';
  statusBarItem.show();
  context.subscriptions.push(statusBarItem);

  // Commands
  context.subscriptions.push(
    vscode.commands.registerCommand('guidance.showPatches', showPanel),
    vscode.commands.registerCommand('guidance.clearPatches', clearAll),
    vscode.commands.registerCommand('guidance.markDone', markCurrentDone),
    vscode.commands.registerCommand('guidance.assignColour', assignColourCommand),
    vscode.commands.registerCommand('guidance.manageColours', manageColoursCommand)
  );

  // Re-apply highlights when switching tabs
  context.subscriptions.push(
    vscode.window.onDidChangeActiveTextEditor(ed => { if (ed) applyToEditor(ed); })
  );

  // Clear highlights on save
  context.subscriptions.push(
    vscode.workspace.onDidSaveTextDocument(doc => onSave(doc.uri.fsPath))
  );

  // Apply colour when workspace folder changes
  context.subscriptions.push(
    vscode.workspace.onDidChangeWorkspaceFolders(() => applyWorkspaceColour())
  );

  startServer(context);
  applyWorkspaceColour();
  writeColorTabsConfig();
}

// ── Tab colour system ───────────────────────────────────────────────────

// Get stored project colour mappings from VS Code settings
function getProjectColours() {
  return vscode.workspace.getConfiguration('guidance').get('projectColours') || {};
}

// Save project colour mappings
async function saveProjectColours(map) {
  await vscode.workspace.getConfiguration('guidance').update(
    'projectColours', map, vscode.ConfigurationTarget.Global
  );
}

// Apply colour to a specific folder's .vscode/settings.json
async function applyColourToFolder(folderPath, colour) {
  const vscodeDir = path.join(folderPath, '.vscode');
  const settingsPath = path.join(vscodeDir, 'settings.json');
  try {
    if (!fs.existsSync(vscodeDir)) fs.mkdirSync(vscodeDir, { recursive: true });
    let settings = {};
    if (fs.existsSync(settingsPath)) {
      try { settings = JSON.parse(fs.readFileSync(settingsPath, 'utf8')); } catch(e) {}
    }
    settings['workbench.colorCustomizations'] = {
      ...(settings['workbench.colorCustomizations'] || {}),
      'titleBar.activeBackground': colour,
      'titleBar.activeForeground': '#ffffff',
      'titleBar.inactiveBackground': colour + 'CC',
      'activityBar.background': colour,
      'activityBar.foreground': '#ffffff',
      'statusBar.background': colour,
      'statusBar.foreground': '#ffffff'
    };
    settings['peacock.color'] = colour;
    fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2));
  } catch(e) {
    vscode.window.showErrorMessage(`Guidance: Could not write colour to ${folderPath}.`);
    console.error('Guidance colour error:', e);
  }
}

// Apply colours to ALL workspace folders on startup
async function applyWorkspaceColour() {
  const folders = vscode.workspace.workspaceFolders;
  if (!folders) return;
  const projectColours = getProjectColours();
  for (const folder of folders) {
    const fp = folder.uri.fsPath;
    let matchedColour = null;
    let bestLen = 0;
    for (const [p, c] of Object.entries(projectColours)) {
      const normP = p.replace(/\\/g, '/').toLowerCase();
      const normF = fp.replace(/\\/g, '/').toLowerCase();
      if ((normF === normP || normF.startsWith(normP)) && normP.length > bestLen) {
        matchedColour = c;
        bestLen = normP.length;
      }
    }
    if (matchedColour) await applyColourToFolder(fp, matchedColour);
  }
}

// Remove colour from workspace
async function removeWorkspaceColour() {
  const folders = vscode.workspace.workspaceFolders;
  if (!folders) return;
  const settingsPath = path.join(folders[0].uri.fsPath, '.vscode', 'settings.json');
  if (!fs.existsSync(settingsPath)) return;
  try {
    let settings = JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
    delete settings['workbench.colorCustomizations'];
    delete settings['peacock.color'];
    fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2));
  } catch(e) {}
}

// Write ColorTabs config to user settings.json automatically
async function writeColorTabsConfig() {
  const projectColours = getProjectColours();
  if (Object.keys(projectColours).length === 0) return;

  // Build ColorTabs config entries from project colours
  const colorTabsConfig = Object.entries(projectColours).map(([folderPath, colour]) => ({
    regex: path.basename(folderPath),
    color: colour
  }));

  // Find user settings.json path
  const appData = process.env.APPDATA || (process.platform === 'darwin'
    ? path.join(process.env.HOME, 'Library', 'Application Support')
    : path.join(process.env.HOME, '.config'));
  const userSettingsPath = path.join(appData, 'Code', 'User', 'settings.json');

  try {
    let settings = {};
    if (fs.existsSync(userSettingsPath)) {
      try { settings = JSON.parse(fs.readFileSync(userSettingsPath, 'utf8')); } catch(e) {}
    }
    settings['colorTabs.config'] = colorTabsConfig;
    settings['colorTabs.activityBarBackground'] = true;
    settings['colorTabs.ignoreCase'] = true;
    fs.writeFileSync(userSettingsPath, JSON.stringify(settings, null, 4));
  } catch(e) {
    console.error('Guidance: could not write ColorTabs config', e);
  }
}

// Command: assign colour to a specific workspace folder
async function assignColourCommand() {
  const folders = vscode.workspace.workspaceFolders;
  if (!folders) {
    vscode.window.showWarningMessage('Guidance: Open a project folder first (File → Open Folder).');
    return;
  }

  // If multiple folders, ask which one to colour
  let targetFolder;
  if (folders.length === 1) {
    targetFolder = folders[0];
  } else {
    const folderItems = folders.map(f => ({
      label: `$(folder) ${f.name}`,
      description: f.uri.fsPath,
      folder: f
    }));
    const picked = await vscode.window.showQuickPick(folderItems, {
      placeHolder: 'Which project do you want to colour?'
    });
    if (!picked) return;
    targetFolder = picked.folder;
  }

  // Pick colour
  const colourItems = COLOURS.flatMap(c =>
    c.shades.map((hex, i) => ({
      label: `$(circle-filled) ${c.name}${i > 0 ? ` (shade ${i + 1})` : ''}`,
      description: hex,
      hex
    }))
  );

  const picked = await vscode.window.showQuickPick(colourItems, {
    placeHolder: `Choose a colour for: ${targetFolder.name}`
  });
  if (!picked) return;

  // Save to global settings map
  const projectColours = getProjectColours();
  projectColours[targetFolder.uri.fsPath] = picked.hex;
  await saveProjectColours(projectColours);

  // Write colour to that folder's .vscode/settings.json
  await applyColourToFolder(targetFolder.uri.fsPath, picked.hex);

  // Auto-update ColorTabs config so tabs colour immediately
  await writeColorTabsConfig();

  vscode.window.showInformationMessage(
    `Guidance: ${targetFolder.name} → ${picked.label.replace('$(circle-filled) ', '')} — tabs coloured automatically ✓`
  );
}

// Command: manage all project colours
async function manageColoursCommand() {
  const projectColours = getProjectColours();
  const entries = Object.entries(projectColours);

  if (entries.length === 0) {
    const choice = await vscode.window.showInformationMessage(
      'Guidance: No project colours assigned yet.',
      'Assign colour to this workspace'
    );
    if (choice) assignColourCommand();
    return;
  }

  const items = [
    ...entries.map(([p, c]) => ({
      label: `$(circle-filled) ${path.basename(p)}`,
      description: `${p}  •  ${c}`,
      action: 'remove', projectPath: p
    })),
    { label: '$(add) Assign colour to current workspace', action: 'add' },
    { label: '$(trash) Clear all project colours', action: 'clearAll' }
  ];

  const picked = await vscode.window.showQuickPick(items, {
    placeHolder: 'Manage project colours — select an entry to remove it'
  });
  if (!picked) return;

  if (picked.action === 'add') {
    assignColourCommand();
  } else if (picked.action === 'clearAll') {
      await saveProjectColours({});
      await removeWorkspaceColour();
      await writeColorTabsConfig();
      vscode.window.showInformationMessage('Guidance: All project colours cleared.');
    } else if (picked.action === 'remove') {
      const projectColours = getProjectColours();
      delete projectColours[picked.projectPath];
      await saveProjectColours(projectColours);
      await removeWorkspaceColour();
      await writeColorTabsConfig();
      vscode.window.showInformationMessage(`Guidance: Colour removed for ${path.basename(picked.projectPath)}.`);
    }
}

// ── WebSocket server ────────────────────────────────────────────────────
function startServer(context) {
  const port = 8765;
  try {
    const ws = require(path.join(context.extensionPath, 'node_modules', 'ws'));
    const WS = ws.WebSocketServer || ws.Server;
    wsServer = new WS({ port, host: '127.0.0.1' });

    wsServer.on('listening', () => {
      statusBarItem.text = '$(eye) Guidance: ready';
    });

    wsServer.on('connection', (sock) => {
      statusBarItem.text = '$(eye) Guidance: browser connected';
      sock.on('message', raw => {
        try { handleMsg(JSON.parse(raw.toString()), sock); } catch(e) {}
      });
      sock.on('close', () => { statusBarItem.text = '$(eye) Guidance: waiting…'; });
      sock.send(JSON.stringify({ type: 'PATCHES_SYNC', patches }));
    });

    wsServer.on('error', err => {
      if (err.code === 'EADDRINUSE') vscode.window.showWarningMessage('Guidance: port 8765 in use. Restart VS Code.');
    });
  } catch(e) {
    statusBarItem.text = '$(eye) Guidance: ws error';
    vscode.window.showErrorMessage('Guidance: WebSocket failed. Run: npm install ws in extension folder.');
  }
}

// ── Handle browser messages ─────────────────────────────────────────────
async function handleMsg(msg, sock) {
  if (msg.type === 'PATCH_DETECTED') {
    const dupKey = (msg.filename || '') + '|' + (msg.rawText || '').slice(0, 80);
    if (patches.some(p => p._dupKey === dupKey && p.status === 'pending')) return;

    const patch = {
      id: msg.id || Date.now(),
      filename: msg.filename,
      language: msg.language,
      instructions: msg.instructions,
      deletions: msg.deletions || [],
      insertions: msg.insertions || [],
      edits: msg.edits || [],
      rawText: msg.rawText || '',
      source: msg.source,
      status: 'pending',
      receivedAt: new Date().toISOString(),
      _dupKey: dupKey
    };

    patches.unshift(patch);
    if (patches.length > 30) patches = patches.slice(0, 30);
    updateBar();

    const editor = await openFile(patch.filename);
    if (editor) {
      await applyHighlights(editor, patch);
      vscode.window.showInformationMessage(
        `Guidance: patch ready in ${path.basename(patch.filename)}`,
        'Show patches'
      ).then(c => { if (c === 'Show patches') showPanel(); });
    }

    if (sock.readyState === 1) sock.send(JSON.stringify({ type: 'ACK', id: patch.id }));
  }

  if (msg.type === 'PATCH_DONE') {
    patches = patches.map(p => p.id === msg.id ? { ...p, status: 'done' } : p);
    updateBar();
    clearDecorations(msg.filename);
  }

  if (msg.type === 'PATCHES_CLEARED') {
    patches = [];
    updateBar();
    vscode.window.visibleTextEditors.forEach(ed => clearAllDecorations(ed));
  }
}

// ── Open file ───────────────────────────────────────────────────────────
async function openFile(filename) {
  if (!filename || filename.startsWith('[')) return vscode.window.activeTextEditor || null;
  for (const ed of vscode.window.visibleTextEditors) {
    if (filenameMatches(filename, ed.document.uri.fsPath)) return ed;
  }
  const base = path.basename(filename);
  const found = await vscode.workspace.findFiles(`**/${base}`, '**/node_modules/**', 5);
  if (found.length > 0) {
    const doc = await vscode.workspace.openTextDocument(found[0]);
    return await vscode.window.showTextDocument(doc, { preview: false });
  }
  if (fs.existsSync(filename)) {
    const doc = await vscode.workspace.openTextDocument(filename);
    return await vscode.window.showTextDocument(doc, { preview: false });
  }
  return null;
}

// ── Apply line highlights ───────────────────────────────────────────────
async function applyHighlights(editor, patch) {
  const lines = editor.document.getText().split('\n');
  const delR = [], insR = [], editR = [];

  (patch.deletions || []).forEach(d => {
    const i = findLine(lines, d.code);
    if (i >= 0) delR.push(lineRange(editor, i));
  });
  (patch.insertions || []).forEach(ins => {
    const hint = Math.min((ins.lineHint || 1) - 1, lines.length - 1);
    insR.push(lineRange(editor, hint));
  });
  (patch.edits || []).forEach(e => {
    const i = findLine(lines, e.code || e);
    if (i >= 0) editR.push(lineRange(editor, i));
  });

  if (delR.length === 0 && insR.length === 0 && editR.length === 0) {
    const rawLines = (patch.rawText || '').split('\n').filter(l => l.trim().length > 5).slice(0, 20);
    for (const rl of rawLines) {
      const i = findLine(lines, rl.trim());
      if (i >= 0) { editR.push(lineRange(editor, i)); break; }
    }
    if (editR.length === 0) {
      for (let i = 0; i < Math.min(5, lines.length); i++) editR.push(lineRange(editor, i));
    }
  }

  editor.setDecorations(decorDelete, delR);
  editor.setDecorations(decorInsert, insR);
  editor.setDecorations(decorEdit, editR);

  const first = delR[0] || editR[0] || insR[0];
  if (first) editor.revealRange(first, vscode.TextEditorRevealType.InCenter);
}

function lineRange(editor, idx) {
  const line = editor.document.lineAt(idx);
  return new vscode.Range(idx, 0, idx, line.text.length);
}

function findLine(lines, search) {
  if (!search || !search.trim()) return -1;
  const needle = search.trim().toLowerCase().slice(0, 40);
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].trim().toLowerCase().includes(needle)) return i;
  }
  return -1;
}

function applyToEditor(editor) {
  const patch = patches.find(p =>
    p.status === 'pending' && filenameMatches(p.filename, editor.document.uri.fsPath)
  );
  if (!patch) { clearAllDecorations(editor); return; }
  applyHighlights(editor, patch);
}

// ── Save handler ────────────────────────────────────────────────────────
function onSave(fsPath) {
  const patch = patches.find(p =>
    p.status === 'pending' && filenameMatches(p.filename, fsPath)
  );
  if (!patch) return;
  patch.status = 'done';
  updateBar();
  clearDecorations(patch.filename);
  vscode.window.showInformationMessage(`✓ Guidance: ${path.basename(patch.filename)} saved — patch done!`);
  broadcast({ type: 'PATCH_DONE', id: patch.id });
}

function clearDecorations(filename) {
  vscode.window.visibleTextEditors.forEach(ed => {
    if (filenameMatches(filename, ed.document.uri.fsPath)) clearAllDecorations(ed);
  });
}

function clearAllDecorations(ed) {
  ed.setDecorations(decorDelete, []);
  ed.setDecorations(decorInsert, []);
  ed.setDecorations(decorEdit, []);
}

// ── Patch panel webview ─────────────────────────────────────────────────
function showPanel() {
  const panel = vscode.window.createWebviewPanel(
    'guidancePatches', 'Guidance — Patches',
    vscode.ViewColumn.Beside, { enableScripts: true }
  );
  panel.webview.html = buildHtml();
  panel.webview.onDidReceiveMessage(msg => {
    if (msg.command === 'markDone') {
      patches = patches.map(p => p.id === msg.id ? { ...p, status: 'done' } : p);
      clearDecorations(msg.filename);
      updateBar();
      panel.webview.html = buildHtml();
      broadcast({ type: 'PATCH_DONE', id: msg.id });
    }
    if (msg.command === 'openFile') openFile(msg.filename);
    if (msg.command === 'clearAll') { clearAll(); panel.webview.html = buildHtml(); }
    if (msg.command === 'assignColour') assignColourCommand();
  });
}

function buildHtml() {
  const pending = patches.filter(p => p.status === 'pending');
  const done = patches.filter(p => p.status === 'done');

  const card = p => {
    const sc = { chatgpt: '#2E7D32', claude: '#534AB7', grok: '#E65100', gemini: '#1565C0' }[p.source] || '#666';
    const sb = { chatgpt: '#E8F5E9', claude: '#EEEDFE', grok: '#FFF3E0', gemini: '#E3F2FD' }[p.source] || '#f5f5f5';
    const isDone = p.status === 'done';
    const diffs = [
      ...(p.deletions || []).map(d => `<div class="dl d"><span class="s">−</span>${esc(d.code)}</div>`),
      ...(p.insertions || []).map(i => `<div class="dl i"><span class="s">+</span>${esc(i.code)}</div>`),
      ...(p.edits || []).map(e => `<div class="dl e"><span class="s">~</span>${esc(e.code || e)}</div>`)
    ].slice(0, 12).join('');

    return `<div class="card${isDone ? ' done' : ''}">
      <div class="ch">
        <span class="fb">${esc(p.filename)}</span>
        <span class="src" style="background:${sb};color:${sc}">${p.source || 'ai'}</span>
        ${isDone ? '<span class="ds">✓ done</span>' : ''}
      </div>
      ${p.instructions ? `<div class="ins">${esc(p.instructions.slice(0, 180))}</div>` : ''}
      ${diffs ? `<div class="diff">${diffs}</div>` : `<div class="raw">${esc((p.rawText || '').slice(0, 250))}</div>`}
      ${!isDone ? `<div class="ac">
        <button onclick="s('openFile','${esc(p.filename)}',${p.id})">Open file ↗</button>
        <button class="p" onclick="s('markDone','${esc(p.filename)}',${p.id})">✓ Mark done</button>
      </div>` : ''}
    </div>`;
  };

  return `<!DOCTYPE html><html><head><meta charset="UTF-8"><style>
  body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;font-size:13px;padding:14px;background:#fff;color:#111}
  h2{font-size:14px;font-weight:600;margin:0 0 3px;display:flex;align-items:center;gap:8px}
  .badge{font-size:11px;background:#EEEDFE;color:#534AB7;padding:2px 8px;border-radius:20px}
  .sub{font-size:11px;color:#999;margin-bottom:10px}
  .colour-btn{font-size:11px;padding:5px 12px;border-radius:7px;border:0.5px solid #534AB7;color:#534AB7;background:#EEEDFE;cursor:pointer;margin-bottom:12px;display:inline-block}
  .card{border:0.5px solid #e0e0e0;border-radius:10px;margin-bottom:10px;overflow:hidden}
  .card.done{opacity:.45}
  .ch{display:flex;align-items:center;gap:8px;padding:8px 11px;background:#fafaf8;border-bottom:0.5px solid #eee;flex-wrap:wrap}
  .fb{font-family:monospace;font-size:11px;font-weight:600;background:#EEEDFE;color:#534AB7;padding:2px 8px;border-radius:20px;word-break:break-all}
  .src{font-size:10px;padding:2px 7px;border-radius:20px;font-weight:500}
  .ds{font-size:10px;color:#3B6D11;background:#EAF3DE;padding:2px 8px;border-radius:20px;margin-left:auto}
  .ins{font-size:11px;color:#555;padding:7px 11px;line-height:1.5;border-bottom:0.5px solid #f0f0f0}
  .diff{font-family:monospace;font-size:11px}
  .dl{display:flex;gap:5px;padding:2px 11px;line-height:1.7}
  .dl.d{background:#FFF2F2;color:#A32D2D}
  .dl.i{background:#F0FBF6;color:#0F6E56}
  .dl.e{background:#FFFBEC;color:#7A5000}
  .s{width:12px;flex-shrink:0;font-weight:700}
  .raw{font-family:monospace;font-size:11px;padding:8px 11px;background:#f7f6f3;white-space:pre-wrap;max-height:100px;overflow-y:auto;color:#555}
  .ac{display:flex;gap:8px;padding:8px 11px}
  button{padding:6px 12px;border-radius:7px;border:0.5px solid #ddd;background:#fff;font-size:12px;cursor:pointer}
  button.p{background:#534AB7;color:#fff;border-color:#534AB7}
  .cb{font-size:11px;padding:4px 10px;border-radius:7px;border:0.5px solid #F09595;color:#A32D2D;cursor:pointer;background:#fff;margin-bottom:10px}
  .st{font-size:10px;text-transform:uppercase;letter-spacing:.07em;color:#aaa;margin:10px 0 5px}
  .empty{text-align:center;padding:2rem;color:#bbb;font-size:12px}
  </style></head><body>
  <h2>Guidance <span class="badge">${pending.length} pending</span></h2>
  <div class="sub">Highlights clear when you save (Ctrl+S)</div>
  <button class="colour-btn" onclick="s('assignColour','',0)">🎨 Assign colour to this workspace</button>
  ${patches.length > 0 ? `<button class="cb" onclick="s('clearAll','',0)">Clear all patches</button>` : ''}
  ${pending.length === 0 ? '<div class="empty">No pending patches — ask an AI for a code change.</div>' : ''}
  ${pending.map(card).join('')}
  ${done.length > 0 ? `<div class="st">Completed</div>${done.map(card).join('')}` : ''}
  <script>
    const vsc = acquireVsCodeApi();
    function s(cmd, filename, id) { vsc.postMessage({ command: cmd, filename, id }); }
    function esc(t) { return String(t).replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
  </script></body></html>`;
}

function esc(s) {
  return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
}

// ── Helpers ──────────────────────────────────────────────────────────────
function filenameMatches(pf, fp) {
  if (!pf || !fp) return false;
  const base = path.basename(pf).toLowerCase();
  const fpBase = path.basename(fp).toLowerCase();
  if (base === fpBase) return true;
  return fp.replace(/\\/g, '/').toLowerCase().endsWith(pf.replace(/\\/g, '/').toLowerCase());
}

function updateBar() {
  const n = patches.filter(p => p.status === 'pending').length;
  statusBarItem.text = n > 0 ? `$(eye) Guidance: ${n} patch${n > 1 ? 'es' : ''} pending` : '$(eye) Guidance: ready';
  statusBarItem.backgroundColor = n > 0 ? new vscode.ThemeColor('statusBarItem.warningBackground') : undefined;
}

function broadcast(msg) {
  if (!wsServer) return;
  const s = JSON.stringify(msg);
  wsServer.clients.forEach(c => { if (c.readyState === 1) c.send(s); });
}

function clearAll() {
  patches = [];
  updateBar();
  vscode.window.visibleTextEditors.forEach(ed => clearAllDecorations(ed));
  broadcast({ type: 'PATCHES_CLEARED' });
}

function markCurrentDone() {
  const ed = vscode.window.activeTextEditor;
  if (ed) onSave(ed.document.uri.fsPath);
}

function deactivate() { if (wsServer) wsServer.close(); }

module.exports = { activate, deactivate };
